const {sequelize} = require('../db');
const { Sequelize } = require('sequelize');

// TODO - create a Menu model

module.exports = {Menu};