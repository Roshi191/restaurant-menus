const {Restaurant} = require('./Restaurant')
const {Menu} = require('./Menu')

module.exports = { Restaurant, Menu }
