const path = require('path');
const { Sequelize } = require('sequelize');

// TODO - connect to db via sequelize

module.exports = {
    sequelize
};
